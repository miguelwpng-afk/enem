# EnemFlow — Organizador de Estudos ENEM

Site estático (HTML + CSS + JavaScript puro). Sem framework, sem build, sem backend.

## Estrutura

```
enemflow/
├── index.html          # estrutura da página
├── _headers            # cabeçalhos HTTP (Cloudflare Pages)
├── .gitignore
└── assets/
    ├── style.css       # estilos (idêntico ao original)
    ├── app.js          # lógica, dados e banco de questões (idêntico ao original)
    └── favicon.svg
```

## Rodar localmente

Use um servidor local em vez de abrir o arquivo com duplo clique:

```
python3 -m http.server 8000
# abra http://localhost:8000
```

## Publicar no GitHub

```
git init
git add .
git commit -m "EnemFlow"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/enemflow.git
git push -u origin main
```

## Publicar no Cloudflare Pages

1. Cloudflare Dashboard → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
2. Escolha o repositório `enemflow`.
3. Configurações de build:
   - **Framework preset:** None
   - **Build command:** (deixe vazio)
   - **Build output directory:** `/` (raiz)
4. **Save and Deploy**. O site fica em `https://enemflow.pages.dev`.

Alternativa sem Git: **Create → Pages → Upload assets** e arraste a pasta.

## Dados do usuário

Tudo (perfil, cronograma, tarefas, respostas, XP) fica no `localStorage` do navegador, na chave `enemflow-v1`. Isso significa:

- os dados são por navegador e por dispositivo (não sincronizam);
- limpar os dados do site apaga o progresso.

Para sincronizar entre dispositivos seria preciso um backend (ex.: Cloudflare D1 ou KV com Pages Functions e login).

## Links externos

Fontes (Google Fonts), YouTube, Google e enemwiki.com.br/INEP são apenas links ou carregamento de fonte; nenhum é chamado por código.
